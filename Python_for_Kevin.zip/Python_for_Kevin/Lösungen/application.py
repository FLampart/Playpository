from customer import Customer
from question import Question
from questionnaire import Questionnaire


class Application:

    def __init__(self):
        self.questionnaire = self.create_questionaire()
        self.customers = []

    def create_questionaire(self):
        def is_nationality(nationality):
            return nationality in ['swiss', 'american', 'german']

        def is_number(string):
            return len(string) > 0 and any(char.isdigit() for char in string)

        def is_name(string):
            return len(string) > 0 and string[0].isupper() and string[1:].islower()

        def is_nationality(string):
            return len(string) == 2 and string.isupper()

        def is_profession(string):
            professions = ['student', 'doctor', 'nurse']
            return string in professions

        questionnaire = Questionnaire()
        questionnaire.add(Question("first_name", "What is the customer's first name?", is_name))
        questionnaire.add(Question("last_name", "What is the customer's last name?", is_name))
        questionnaire.add(Question("age", "What is the customer's age?", is_number))
        questionnaire.add(Question("nationality", "What is the customer's nationality?", is_nationality))
        questionnaire.add(Question("profession", "What is the customer's profession?", is_profession))
        return questionnaire

    def start(self):
        print("Hello to the customer database.")
        self.print_help()

        while(True):
            print("What would you like to do?")
            user_input = raw_input()
            print("")

            if user_input == 'add':
                self.register_new_customer()
            elif user_input == 'list':
                self.list_customers()
            elif user_input == 'exit':
                return
            else:
                print("Invalid action!\n")
                self.print_help()

    def print_help(self):
        print("You can type one of the following actions:\n\nadd - Add a new customer\nlist - list the existing customers\nexit - exit the database\n")

    def register_new_customer(self):
        tmp = self.questionnaire.start()
        self.customers.append(Customer(**tmp))
        print("You successfully registered a new customer.")

    def list_customers(self):
        for customer in self.customers:
            print("First Name: " +  customer.first_name)
            print("Last Name: " + customer.last_name)
            print("Age: " + customer.age)
            print("Profession: " + customer.profession)
            print("Nationality: " + customer.nationality)
            print("")


if __name__ == '__main__':
    Application().start()
